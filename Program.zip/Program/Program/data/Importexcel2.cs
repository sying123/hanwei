﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program.data
{
    class Importexcel2
    {

        public double[,] ImportExcel2(String FileName)
        {
            //string fileName = "";
            //string openFileName = "";
            //OpenFileDialog openDialog = new OpenFileDialog();
            //openDialog.DefaultExt = "xlsx";
            //openDialog.Filter = "Excel文件|*.xlsx";
            //openDialog.FileName = fileName;
            //openDialog.ShowDialog();
            string openFileName = "";
            openFileName = FileName;
            //if (openFileName.IndexOf(":") < 0) return; //被点了取消


            Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            //if (xlApp == null)
            //{
            //    System.Windows.MessageBox.Show("无法创建Excel对象，您的电脑可能未安装Excel");
            //    return;
            //}
            object missing = System.Reflection.Missing.Value;
            Microsoft.Office.Interop.Excel.Workbooks workbook = xlApp.Workbooks;
            workbook.Open(openFileName, missing, true, missing, missing, missing,
                               missing, missing, missing, true, missing, missing, missing, missing, missing);
            Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)xlApp.Worksheets.get_Item(1);

            int rows = worksheet.UsedRange.Rows.Count;
            //行数
            int columns = worksheet.UsedRange.Columns.Count;
            //列数

            string TableName = worksheet.Name;

            double[,] excel2 = new double[2, rows - 1];
            for (int j = 0; j < 2; j++)
            {
                for (int i = 0; i < rows - 1; i++)
                {
                    excel2[j, i] = worksheet.Cells[i + 2, 2 + j].Value;
                  //  Console.WriteLine("{0}", excel2[j, i]);
                }
            }

            //配置文件表格2的导入的二维数组

            System.Windows.MessageBox.Show("配置2数据导入完成！");
            xlApp.Quit();
            GC.Collect();//强行销毁 
            return excel2;
        }
    }
}
