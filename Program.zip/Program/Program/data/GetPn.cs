﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Program.data
{
    class GetPn
    {
        string folder = "";

        public static object Text { get; private set; }

        public string GetPnValue()//将resources里的ini文件中的数据显示在textbox里面
        {
            string aimpath = System.Windows.Forms.Application.StartupPath;//得到ini的路径
            aimpath = aimpath.Substring(0, aimpath.Length - 9);
            folder = System.IO.Path.Combine(aimpath, @"Resources\aaa.ini");
            StreamReader sr1 = new StreamReader(folder);

            // string str1 = sr1.ReadToEnd();

            string path = System.IO.Path.GetFullPath(folder);
            return ContentValue("Section 1", "Pn", path);
        }

        #region
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filepath);
        [DllImport("kernel32")]
        private static extern long GetPrivateProfileString(string section, string key, string def, StringBuilder retval, int size, string filepath);
        #endregion

        private static string ContentValue(string Section, string key, string strFilePath)//读取ini文件
        {
            StringBuilder temp = new StringBuilder(1024);
            long a = GetPrivateProfileString(Section, key, "", temp, 1024, strFilePath);
            return temp.ToString();
        }

    }
}
