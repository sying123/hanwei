﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using Microsoft.Office.Interop.Excel;
using Program.data;
using OpenFileDialog = System.Windows.Forms.OpenFileDialog;
using SaveFileDialog = System.Windows.Forms.SaveFileDialog;
using Line_Chart;
using System.Drawing;
using System.Windows.Forms.DataVisualization.Charting;
using Color = System.Drawing.Color;

namespace Program
{
    /// <summary>
    /// Page1.xaml 的交互逻辑
    /// </summary>
    public partial class Page1 : System.Windows.Controls.Page
    {
        public Page1()
        {
            InitializeComponent();
            GetPn Pn = new GetPn();
            this.GetPn.Text = Pn.GetPnValue();//获取Pn值
        }

        private void Button_Click(object sender, RoutedEventArgs e)//获取第一个配置文件的路径
        {
            //选择第一个配置文件
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "*.xlsx|*.xlsx|*.xls|*.xls";// *.dxd | *.dxd | *.d7d | *.d7d
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (openFileDialog1.FileName != "")
                {
                    this.text1.Text = openFileDialog1.FileName;
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)//获取第二个配置文件的路径
        {
            //选择第二个配置文件
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "*.xlsx|*.xlsx|*.xls|*.xls";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (openFileDialog1.FileName != "")
                {
                    this.text2.Text = openFileDialog1.FileName;
                }
            }
        }

        private void ModelDownload1_Click(object sender, RoutedEventArgs e)//下载配置文件，第一种方法
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Title = "导出配置文件";
            dlg.FileName = "波形过程表格.xls";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                //检查路径正确性
                if (dlg.FileName.Trim().Length <= 0)
                {
                    System.Windows.Forms.MessageBox.Show("请选择路径。");
                    return;
                }
                //检查文件夹是否存在
                int n = dlg.FileName.LastIndexOf(@"\") + 1;
                if (n < 0)
                {
                    System.Windows.Forms.MessageBox.Show("路径错误。");
                    return;
                }
                string PathStr = dlg.FileName.Substring(0, n);
                if (!Directory.Exists(PathStr))
                {
                    System.Windows.Forms.MessageBox.Show("路径不存在，请检查。");
                    return;
                }
                //导出 我的Excel资源：configurationFile1.xls
                byte[] template = Properties.Resources.configurationFile1;//Excel资源去掉后缀名                                                                    
                FileStream stream = new FileStream(dlg.FileName, FileMode.Create);
                stream.Write(template, 0, template.Length);
                System.Windows.Forms.MessageBox.Show("下载成功！", "result");
                stream.Close();
                stream.Dispose();
            }
        }

        private void ModelDownload2_Click(object sender, RoutedEventArgs e)//下载配置文件，第二种方法
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Title = "导出配置文件";
            dlg.FileName = "波形突变幅值设置.xls";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                //检查路径正确性
                if (dlg.FileName.Trim().Length <= 0)
                {
                    System.Windows.Forms.MessageBox.Show("请选择路径。");
                    return;
                }
                //检查文件夹是否存在
                int n = dlg.FileName.LastIndexOf(@"\") + 1;
                if (n < 0)
                {
                    System.Windows.Forms.MessageBox.Show("路径错误。");
                    return;
                }
                string PathStr = dlg.FileName.Substring(0, n);
                if (!Directory.Exists(PathStr))
                {
                    System.Windows.Forms.MessageBox.Show("路径不存在，请检查。");
                    return;
                }
                //导出 我的Excel资源：TestMasterplate.xls
                byte[] template = Properties.Resources.configurationFile2;//Excel资源去掉后缀名
                File.WriteAllBytes(dlg.FileName, template);
                System.Windows.Forms.MessageBox.Show("下载成功！", "result");
            }
        }

        //private void ModelUpload1_Click(object sender, RoutedEventArgs e)//将路径文件导入项目
        //{
        //    OpenFileDialog model1 = new OpenFileDialog();
        //    model1.Filter = "文本文件|*.*|C#文件|*.cs|所有文件|*.*|表格文件|*.xlsx";
        //    if (model1.ShowDialog() == DialogResult.OK)
        //    {
        //        if (model1.FileName != "")
        //        {
        //            srcpath =model1.FileName;
        //        }
        //    }
        //    string aimpath = System.Windows.Forms.Application.StartupPath ;//获取resource路径
        //    aimpath= aimpath.Substring(0,aimpath.Length-9);//截取resource路径bin前的字符串
        //    string folder = System.IO.Path.Combine(aimpath, @"Resources\configurationFile1.xlsx");  //将截取的字符串与Resources\configurationFile1.xlsx连接     
        //    if (File.Exists(folder))//是否存在，存在则覆盖
        //    {
        //        File.Delete(folder);//删除原文件
        //        File.Copy(srcpath, @"D:\VS test\Program\Program\Resources\configurationFile1.xlsx");//将更改之后的文件复制，并取名
        //        System.Windows.Forms.MessageBox.Show("添加成功！", "result");
        //    }
        //}

        private void OpenData_Click(object sender, RoutedEventArgs e)//获取数据文件路径并获取数据
        {
            OpenFileDialog file = new OpenFileDialog
            {
                Multiselect = true,
                Filter = "*.dxd|*.dxd|*.d7d|*.d7d",
                FileName = ""
            };
            //file.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;//与可执行文件一个路径
            if (file.ShowDialog() == DialogResult.OK)
            {
                DWDataReader dWDataReader = new DWDataReader();
                if (dWDataReader.DWDataOpenFile(file.FileName))
                {
                    text3.Text = file.FileName;
                    for (Int64 i = 0; i < dWDataReader.DwChannelCount; i++)
                    {
                        if (dWDataReader.DwChannelData[i].data != null)
                        {
                            ComboBox.Items.Add(dWDataReader.DwChannelList[i].name);
                        }
                    }
                    dWDataReader.DWDataCloseFile();
                    //for (int j = 0; j < dWDataReader.DwChannelData[159].data.Length; j++)
                    //{
                    //    ComboBox3.Items.Add(dWDataReader.DwChannelData[159].data[j]);
                    //}
                }
                else
                    System.Windows.Forms.MessageBox.Show("打开失败！");
            }
        }


        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //DataGrid_SelectionChanged();
        }

        private void DataGrid_SelectionChanged(System.Data.DataTable dt)//未实现
        {
            string fileName = "";
            string saveFileName = "";
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.DefaultExt = "xlsx";
            saveDialog.Filter = "Excel文件|*.xlsx";
            saveDialog.FileName = fileName;
            saveDialog.ShowDialog();
            saveFileName = saveDialog.FileName;
            if (saveFileName.IndexOf(":") < 0) return; //被点了取消
            Microsoft.Office.Interop.Excel.Application xlApp =
                                new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                System.Windows.MessageBox.Show("无法创建Excel对象，您的电脑可能未安装Excel");
                return;
            }
            Microsoft.Office.Interop.Excel.Range range;
            Microsoft.Office.Interop.Excel.Workbooks workbooks = xlApp.Workbooks;
            Microsoft.Office.Interop.Excel.Workbook workbook =
                        workbooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);
            Microsoft.Office.Interop.Excel.Worksheet worksheet =
                        (Microsoft.Office.Interop.Excel.Worksheet)workbook.Worksheets[1];//取得sheet1 
            int rowIndex = 1; //行的起始下标为 1
            int colIndex = 1; //列的起始下标为 1
                              //设置列名
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                //设置第一行，即列名
                worksheet.Cells[rowIndex, colIndex + i] = dt.Columns[i].ColumnName;

                //获取第一行的每个单元格
                range = worksheet.Cells[rowIndex, colIndex + i];
                //设置单元格的内部颜色
                range.Interior.ColorIndex = 33;
                //字体加粗
                range.Font.Bold = true;
                //设置为黑色
                range.Font.Color = 0;
                //设置为宋体
                range.Font.Name = "Arial";
                //设置字体大小
                range.Font.Size = 12;
                //水平居中
                range.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                //垂直居中
                range.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
            }

            //跳过第一行，第一行写入了列名
            rowIndex++;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    worksheet.Cells[rowIndex + i, colIndex + j] = dt.Rows[i][j].ToString();
                }
            }
            worksheet.Columns.EntireColumn.AutoFit();//列宽自适应
            xlApp.Cells.HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlCenter; //全局居中对齐

            xlApp.DisplayAlerts = false;
            System.Windows.MessageBox.Show(fileName + "资料保存成功", "提示", MessageBoxButton.OK);
            if (saveFileName != "")
            {
                try
                {
                    workbook.Saved = true;
                    workbook.SaveCopyAs(saveFileName);  //fileSaved = true;                 
                }
                catch (Exception ex)
                {//fileSaved = false;                      
                    System.Windows.MessageBox.Show("导出文件时出错,文件可能正被打开！\n" + ex.Message);
                }
            }
            xlApp.Quit();
            GC.Collect();//强行销毁   
        }

        //private void GetPn_Click(object sender, RoutedEventArgs e)//从ini配置文件里获得Pn值
        //{
        //    GetPn Pn = new GetPn();
        //    this.GetPn.Text = Pn.GetPnValue();
        //}

        //点击“开始分析”按钮
        private void ActiveCompute_Click(object sender, RoutedEventArgs e)
        {
            //
            //
            //调用计算方法！！
            //
            //
            Form1 form1 = new Form1();//打开LineChar
            this.OpenForm(form1);
            double[] xData = { 0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,2,2.1,2.2,2.3,2.4,2.5,2.6,2.7,2.8,2.9,3,3.1,3.2,3.3,3.4,3.5,3.6,3.7,3.8,3.9,4,4,4,4,4,4,4,4,4,4};
            double[] yData = { 100,100,100,100, 100, 100, 100, 100 , 100, 100, 100, 100 , 100, 100, 100, 100 , 100, 100, 100, 100 , 100, 100, 100, 100 , 100, 100, 100, 100 , 100, 100, 100, 100 , 100, 100, 100, 100 , 100, 100, 100, 100,99, 98,97,96,95,94,93,92,91,90};
            form1.GetChart(xData,yData);//调用Form1的GetChart方法
        }

        public void OpenForm(Form objForm)
        {
            objForm.TopLevel = false;//将当前子窗体设置成非顶级控件
            objForm.WindowState = FormWindowState.Maximized;//设置窗体最大化
            objForm.FormBorderStyle = FormBorderStyle.None;//去掉窗体边框
            objForm.Parent = this.draw;//指定当前子窗体显示的容器
            objForm.Show();
        }

        private void Calculate()//开始计算
        {
            Importexcel1 m = new Importexcel1();
            Importexcel2 m1 = new Importexcel2();
            string path1 = this.text1.Text;
            string path2 = this.text2.Text;
            if (string.IsNullOrEmpty(path1) == false && string.IsNullOrEmpty(path2) == false)
            {
                double[,] excel1 = m.ImportExcel1(path1);//获取配置1数组
                double[,] excel2 = m1.ImportExcel2(path2);//获取配置2数组
            }
            else
            {
                System.Windows.MessageBox.Show("请导入两个配置文件！\n");
            }
        }
    }
}

