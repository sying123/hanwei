﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Line_Chart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        ///*
        // 点击按钮绘图
        //     */
        public void GetChart(double[] xData,double[] yData)
        {
            //List<float> xData = new List<float>();//定义x数据
            //List<float> yData = new List<float>();//定义y数据

            //生成xy的数据
            //for (int i = 0; i < 10; i++)
            //{
            //    xData.Add(float.Parse((i + 0.2).ToString()));
            //}
            //for (int i = 0; i < 10; i++)
            //{
            //    yData.Add(float.Parse((3 * i + 1).ToString()));
            //}
            /*
             * 在form里放一个chart
             */
            int[] AxisDesign = {4, 28, 20, 100 };
            string[] AxisTitle = {"时间（min）","有功功率设定值", "（额定功率百分比，%）" };

            var chart = chart1.ChartAreas[0];
            chart.AxisX.IntervalType = DateTimeIntervalType.Number;

            chart.AxisX.LabelStyle.Format = "";
            chart.AxisY.LabelStyle.Format = "";
            chart.AxisY.LabelStyle.IsEndLabelVisible = true;

            //定义坐标轴的范围、间隔和标题
            chart.AxisX.Minimum = 0;
            chart.AxisX.Maximum = AxisDesign[1];
            chart.AxisY.Minimum = 0;
            chart.AxisY.Maximum = AxisDesign[3];
            chart.AxisX.Interval = AxisDesign[0];
            chart.AxisY.Interval = AxisDesign[2];
            chart.AxisX.Title =AxisTitle[0];
            chart.AxisY.Title = AxisTitle[1] + Environment.NewLine + AxisTitle[2];//+ Environment.NewLine +实现换行输出

            //设置网格颜色
            chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.Transparent;
            chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.Transparent;

            //折线的索引
            chart1.Series.Add("line1");

            //折线图
            chart1.Series["line1"].ChartType = SeriesChartType.Line;
            //曲线图
            //chart1.Series["line1"].ChartType = SeriesChartType.Spline;

            //线条的颜色
            chart1.Series["line1"].Color = Color.Black;
            chart1.Series[0].IsVisibleInLegend = false;
            //chart1.Series["line1"].IsValueShownAsLabel = true;//是否显示数据值

            //绘制折线
            chart1.Series["line1"].Points.DataBindXY(xData, yData);

            //标注点的设置
            //另外定义一个绘制散点的对象，设置颜色等
            chart1.Series.Add("points");
            chart1.Series["points"].Color = Color.Transparent;
            chart1.Series["points"].MarkerColor = Color.Red;
            chart1.Series["points"].MarkerSize = 8;
            chart1.Series["points"].MarkerStyle = MarkerStyle.Circle;
            chart1.Series["points"].IsVisibleInLegend = false;
            //所要标注的散点
            double[] x0 = { xData[10], xData[41] };
            double[] y0 = { yData[10], yData[41] };
            for(int i = 0; i < x0.Length; i++)
            {
                chart1.Series["points"].Points.AddXY(x0[i], y0[i]);
            }

            //标注框的设置
            string[] textTitle = { "t0=1", "t1=2" };
            for (int j = 0; j < x0.Length; j++)
            {
                CalloutAnnotation calloutAnnotation = new CalloutAnnotation();//新建实例
                calloutAnnotation.BackColor = Color.White;//背景色
                calloutAnnotation.LineColor = Color.Red;//批注线颜色
                calloutAnnotation.ForeColor = Color.Red;//批注文本颜色
                calloutAnnotation.AllowMoving = true;//是否移动
                calloutAnnotation.CalloutStyle = CalloutStyle.Borderline;//设置为矩形
                calloutAnnotation.CalloutAnchorCap = LineAnchorCapStyle.None;//箭头设置为无
                //将标注放在list中
                List<CalloutAnnotation> listannotations = new List<CalloutAnnotation>();//存放标注的list：listannotations

                //将某个标注加入list
                calloutAnnotation.AnchorDataPoint = chart1.Series["points"].Points[j];
                calloutAnnotation.Text = textTitle[j];
                listannotations.Add(calloutAnnotation);

                //绘制标注框
                foreach (CalloutAnnotation item in listannotations)
                {
                    chart1.Annotations.Add(item);
                }
            }
        }
    }
}
