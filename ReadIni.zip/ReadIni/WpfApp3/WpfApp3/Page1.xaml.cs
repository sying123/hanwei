﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using Path = System.IO.Path;
using System.ComponentModel;
using System.Linq.Expressions;


namespace WpfApp3

{
    /// <summary>
    /// Page1.xaml 的交互逻辑
    /// </summary>
    //public static Page1 page1;

    public partial class Page1 : Page
    {

        string defaultPath;

        #region
        [DllImport("kernel32")]//section字段名，key键，value键值,filepath配置文件路径
        private static extern long WritePrivateProfileString(string section, string key, string val, string filepath);
        [DllImport("kernel32")]//section字段名，key键，def如果INI文件中没有前两个参数指定的字段名或键名,则将此值赋给变量,
                               //retval接收INI文件中的值的CString对象,即目的缓存器.
                               //size目的缓存器的大小，filepath文件名
        private static extern long GetPrivateProfileString(string section, string key, string def, StringBuilder retval, int size, string filepath);
        #endregion

        public Page1()
        {
            InitializeComponent();
            this.lujing();
        }


        private void Liulan(object sender, RoutedEventArgs e)//点击浏览按钮 弹出选择文件对话框
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory + "";    //打开对话框后的初始目录 当前文件的位置
            fileDialog.Filter = "配置文件|*.ini|所有文件|*.*";//筛选ini文件
            fileDialog.RestoreDirectory = false;//若为false，则打开对话框后为上次的目录。若为true，则为初始目录
            if (fileDialog.ShowDialog() == DialogResult.OK)//当点击文件时
            {
                //StreamReader sr = new StreamReader(fileDialog.FileName);
                //string str = sr.ReadToEnd();//读ini里面的数据
                string currentPath = fileDialog.FileName;//获取的ini路径名字
                FilePath.Text = currentPath;

                Textbox1.Text = ContentValue("Section1", "Un", currentPath);
                Textbox2.Text = ContentValue("Section1", "Pn", currentPath);
                Textbox3.Text = ContentValue("Section1", "Sn", currentPath);
                Textbox4.Text = ContentValue("Section1", "JZDL", currentPath);
                Textbox5.Text = ContentValue("Section1", "JBSD", currentPath);//JDSB
                Textbox6.Text = ContentValue("Section1", "Fn", currentPath);
                Textbox7.Text = ContentValue("Section1", "In", currentPath);
                Textbox8.Text = ContentValue("Section1", "Place", currentPath);
                Textbox9.Text = ContentValue("Section1", "ZXDL", currentPath);
                Textbox10.Text = ContentValue("Section1", "YDXY", currentPath);
            }
        }

        public void lujing()//将resources里的ini文件中的数据显示在textbox里面
        {
            string aimpath = System.Windows.Forms.Application.StartupPath;//得到ini的路径
            aimpath = aimpath.Substring(0, aimpath.Length - 9);//截取
            string folder = System.IO.Path.Combine(aimpath, @"Resources\default.ini");//加上后缀
            //StreamReader sr1 = new StreamReader(folder);
            //string str1 = sr1.ReadToEnd();
            this.defaultPath = System.IO.Path.GetFullPath(folder);
            Textbox1.Text = ContentValue("Section1", "Un", defaultPath);
            Textbox2.Text = ContentValue("Section1", "Pn", defaultPath);
            Textbox3.Text = ContentValue("Section1", "Sn", defaultPath);
            Textbox4.Text = ContentValue("Section1", "JZDL", defaultPath);
            Textbox5.Text = ContentValue("Section1", "JBSD", defaultPath);
            Textbox6.Text = ContentValue("Section1", "Fn", defaultPath);
            Textbox7.Text = ContentValue("Section1", "In", defaultPath);
            Textbox8.Text = ContentValue("Section1", "Place", defaultPath);
            Textbox9.Text = ContentValue("Section1", "ZXDL", defaultPath);
            Textbox10.Text = ContentValue("Section1", "YDXY", defaultPath);
        }

        private static string ContentValue(string Section, string key, string strFilePath)//读取ini文件
        {
            StringBuilder temp = new StringBuilder(255);
            long i = GetPrivateProfileString(Section, key, "没找到", temp, 255, strFilePath);
            //System.Windows.MessageBox.Show(Section);
            //System.Windows.MessageBox.Show(key);
            //System.Windows.MessageBox.Show(strFilePath);
            //System.Windows.MessageBox.Show(temp.ToString());
            return temp.ToString();

        }

        private void Yingyong(object sender, RoutedEventArgs e)
        {
            string Un = Textbox1.Text;
            string Pn = Textbox2.Text;
            string Sn = Textbox3.Text;
            string JZDL = Textbox4.Text;
            string JBSD = Textbox5.Text;
            string Fn = Textbox6.Text;
            string In = Textbox7.Text;
            string Place = Textbox8.Text;
            string ZXDL = Textbox9.Text;
            string YDXY = Textbox10.Text;

            WritePrivateProfileString("Section1", "Un", Un, defaultPath);
            WritePrivateProfileString("Section1", "Pn", Pn, defaultPath);
            WritePrivateProfileString("Section1", "Sn", Sn, defaultPath);
            WritePrivateProfileString("Section1", "JZDL", JZDL, defaultPath);
            WritePrivateProfileString("Section1", "JBSD", JBSD, defaultPath);
            WritePrivateProfileString("Section1", "Fn", Fn, defaultPath);
            WritePrivateProfileString("Section1", "In", In, defaultPath);
            WritePrivateProfileString("Section1", "Place", Place, defaultPath);
            WritePrivateProfileString("Section1", "ZXDL", ZXDL, defaultPath);
            WritePrivateProfileString("Section1", "YDXY", YDXY, defaultPath);
        }


        private void Save(object sender, RoutedEventArgs e)
        {
            if (FilePath.Text == "")
            {
                string Un = Textbox1.Text;
                string Pn = Textbox2.Text;
                string Sn = Textbox3.Text;
                string JZDL = Textbox4.Text;
                string JBSD = Textbox5.Text;
                string Fn = Textbox6.Text;
                string In = Textbox7.Text;
                string Place = Textbox8.Text;
                string ZXDL = Textbox9.Text;
                string YDXY = Textbox10.Text;

                WritePrivateProfileString("Section1", "Un", Un, defaultPath);
                WritePrivateProfileString("Section1", "Pn", Pn, defaultPath);
                WritePrivateProfileString("Section1", "Sn", Sn, defaultPath);
                WritePrivateProfileString("Section1", "JZDL", JZDL, defaultPath);
                WritePrivateProfileString("Section1", "JBSD", JBSD, defaultPath);
                WritePrivateProfileString("Section1", "Fn", Fn, defaultPath);
                WritePrivateProfileString("Section1", "In", In, defaultPath);
                WritePrivateProfileString("Section1", "Place", Place, defaultPath);
                WritePrivateProfileString("Section1", "ZXDL", ZXDL, defaultPath);
                WritePrivateProfileString("Section1", "YDXY", YDXY, defaultPath);
            }
            else
            {
                string currentPath = FilePath.Text;

                string Un = Textbox1.Text;
                string Pn = Textbox2.Text;
                string Sn = Textbox3.Text;
                string JZDL = Textbox4.Text;
                string JBSD = Textbox5.Text;
                string Fn = Textbox6.Text;
                string In = Textbox7.Text;
                string Place = Textbox8.Text;
                string ZXDL = Textbox9.Text;
                string YDXY = Textbox10.Text;
                //应用到default.ini
                WritePrivateProfileString("Section1", "Un", Un, defaultPath);
                WritePrivateProfileString("Section1", "Pn", Pn, defaultPath);
                WritePrivateProfileString("Section1", "Sn", Sn, defaultPath);
                WritePrivateProfileString("Section1", "JZDL", JZDL, defaultPath);
                WritePrivateProfileString("Section1", "JBSD", JBSD, defaultPath);
                WritePrivateProfileString("Section1", "Fn", Fn, defaultPath);
                WritePrivateProfileString("Section1", "In", In, defaultPath);
                WritePrivateProfileString("Section1", "Place", Place, defaultPath);
                WritePrivateProfileString("Section1", "ZXDL", ZXDL, defaultPath);
                WritePrivateProfileString("Section1", "YDXY", YDXY, defaultPath);
                //应用到当前的ini
                WritePrivateProfileString("Section1", "Un", Un, currentPath);
                WritePrivateProfileString("Section1", "Pn", Pn, currentPath);
                WritePrivateProfileString("Section1", "Sn", Sn, currentPath);
                WritePrivateProfileString("Section1", "JZDL", JZDL, currentPath);
                WritePrivateProfileString("Section1", "JBSD", JBSD, currentPath);
                WritePrivateProfileString("Section1", "Fn", Fn, currentPath);
                WritePrivateProfileString("Section1", "In", In, currentPath);
                WritePrivateProfileString("Section1", "Place", Place, currentPath);
                WritePrivateProfileString("Section1", "ZXDL", ZXDL, currentPath);
                WritePrivateProfileString("Section1", "YDXY", YDXY, currentPath);
            }
        }

        private void changeUn(object sender, TextChangedEventArgs e)
        {
            string Un = Textbox1.Text;
            double UN;
            string Sn = Textbox3.Text;
            double SN;
            string In = Textbox7.Text;
            if (Un == "" || Sn == "")
            {
                //UN = Convert.ToDouble(Un);
                SN = 0.0;
                UN = 0.0;
                Textbox7.Text = (0.0).ToString();
            }
            else
            {
                if (Un != ""&& Un!="没找到" )
                {
                    UN = Convert.ToDouble(Un);
                }
                else
                {
                    UN = 0.0;
                }
                if (Sn != ""&&Sn!="没找到")
                {
                    SN = Convert.ToDouble(Sn);
                }
                else
                {
                    SN = 0.0;
                }
                Textbox7.Text = (UN / SN / Math.Sqrt(3)).ToString();
            }

        }

        private void changeSn(object sender, TextChangedEventArgs e)
        {
            string Un = Textbox1.Text;
            double UN;
            string Sn = Textbox3.Text;
            double SN;
            string In = Textbox7.Text;
            if (Un == "" || Sn == "")
            {
                //UN = Convert.ToDouble(Un);
                SN = 0.0;
                UN = 0.0;
                Textbox7.Text = (0.0).ToString();
            }
            else
            {
                if (Un != ""&&Sn!="没找到")
                {
                    UN = Convert.ToDouble(Un);
                }
                else
                {
                    UN = 0.0;
                }
                if (Sn != ""&&Sn!="没找到")
                {
                    SN = Convert.ToDouble(Sn);
                }
                else
                {
                    SN = 0.0;
                }
                Textbox7.Text = (UN / SN / Math.Sqrt(3)).ToString();
            }
        }
        string localFilePath = "";
        private void SaveAs(object sender, RoutedEventArgs e)//另存为按钮
        {
            string  fileNameExt = "", newFileName = "", FilePath = "";
            Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog();
            saveFileDialog.FileName = "Document"; // Default file name
            saveFileDialog.DefaultExt = ".ini"; // Default file extension
            saveFileDialog.Filter = "Ini documents (.ini)|*.ini"; // Filter files by extension

            // Show save file dialog box
            Nullable<bool> result = saveFileDialog.ShowDialog();

            // Process save file dialog box results
            if (result == true)
            {
                // Save document
                localFilePath = saveFileDialog.FileName.ToString();//获得文件路径
                //System.Windows.MessageBox.Show(localFilePath);
                //fileNameExt = localFilePath.Substring(localFilePath.LastIndexOf("\\") + 1);//获取文件名，不带路径
                //FilePath = localFilePath.Substring(0, localFilePath.LastIndexOf("\\"));//获取文件路径，不带文件名
                if (saveFileDialog.FileName.Trim().Length <= 0)
                {
                    System.Windows.Forms.MessageBox.Show("请选择路径。");
                    return;
                }
                //检查文件夹是否存在
                int n = saveFileDialog.FileName.LastIndexOf(@"\") + 1;
                if (n < 0)
                {
                    System.Windows.Forms.MessageBox.Show("路径错误。");
                    return;
                }
                string PathStr = saveFileDialog.FileName.Substring(0, n);
                if (!Directory.Exists(PathStr))
                {
                    System.Windows.Forms.MessageBox.Show("路径不存在，请检查。");
                    return;
                }
                string template = Properties.Resources.another ;//Excel资源去掉后缀名

                byte[] byteArray = System.Text.Encoding.Default.GetBytes(template);
                FileStream stream = new FileStream(saveFileDialog.FileName, FileMode.Create);
                stream.Write(byteArray, 0, byteArray.Length);
                //System.Windows.Forms.MessageBox.Show("下载成功！", "result");
                stream.Close();
                stream.Dispose();
            }

        }




    }
    }

















