﻿using PQAnalyze.Service;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Page2.xaml 的交互逻辑
    /// </summary>
    public partial class Page2 : Page
    {
        public Page2()
        {
            InitializeComponent();
        }


        private void Button_Clickin(object sender, RoutedEventArgs e)//获取数据文件路径并获取数据
        {
            OpenFileDialog file = new OpenFileDialog
            {
                Multiselect = true,
                Filter = "*.dxd|*.dxd|*.d7d|*.d7d",
                FileName = ""
            };
            //file.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;//与可执行文件一个路径
            if (file.ShowDialog() == DialogResult.OK)
            {
                DWDataReader dWDataReader = new DWDataReader();
                if (dWDataReader.DWDataOpenFile(file.FileName))
                {
                    Textbox1.Text = file.FileName;
                    int a = 0;
                    for (Int64 i = 0; i < dWDataReader.DwChannelCount; i++)
                    {
                        if (dWDataReader.DwChannelData[i].data != null)
                        {
                           
                            if (dWDataReader.DwChannelList[i].name == "P_H1")
                            {
                                a = a + 1;
                                //ComboBox.Text = "P_H1";
                            }
                            //else
                            //{
                            //    ComboBox.Text = "请选择";
                            //}
                            ComboBox.Items.Add(dWDataReader.DwChannelList[i].name);
                        }
                        if (a >= 1)
                        {
                            ComboBox.Text = "P_H1";
                        }
                        if (a < 1)
                        {
                            ComboBox.Text = "请选择";
                        }
                    }

                    //if (dWDataReader.DwChannelData[i].data != null)
                    //{
                    //    ComboBox.Items.Add(dWDataReader.DwChannelList[i].name);
                    //}
                }
                dWDataReader.DWDataCloseFile();
                //for (int j = 0; j < dWDataReader.DwChannelData[159].data.Length; j++)
                //{
                //    ComboBox3.Items.Add(dWDataReader.DwChannelData[159].data[j]);
                //}
            }
            else
                System.Windows.Forms.MessageBox.Show("打开失败！");
        }

        private void Button_Clickout(object sender, RoutedEventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog
            {
                Multiselect = true,
                Filter = "*.dxd|*.dxd|*.d7d|*.d7d",
                FileName = ""
            };
            //file.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory;//与可执行文件一个路径
            if (file.ShowDialog() == DialogResult.OK)
            {
                DWDataReader dWDataReader = new DWDataReader();
                if (dWDataReader.DWDataOpenFile(file.FileName))
                {
                    Textbox2.Text = file.FileName;
                    int a = 0;
                    for (Int64 i = 0; i < dWDataReader.DwChannelCount; i++)
                    {
                        if (dWDataReader.DwChannelData[i].data != null)
                        {

                            if (dWDataReader.DwChannelList[i].name == "P_H1")
                            {
                                a = a + 1;
                               
                            }
                           
                            ComboBox.Items.Add(dWDataReader.DwChannelList[i].name);
                        }
                        if (a >= 1)
                        {
                            ComboBox.Text = "P_H1";
                        }
                        if (a < 1)
                        {
                            ComboBox.Text = "请选择";
                        }
                    }                   
                }
                dWDataReader.DWDataCloseFile();
                
            }
            else
                System.Windows.Forms.MessageBox.Show("打开失败！");
        }

        private void button_Clickcontinue(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog1 = new FolderBrowserDialog();
            //folder控件描述Environment.SpecialFolder.Desktop;
            folderBrowserDialog1.Description = "请选择一个包含DXD格式的文件夹：";
            //指定folder根=桌面
            folderBrowserDialog1.RootFolder = Environment.SpecialFolder.Desktop;
            //是否添加新建文件夹的按钮
            folderBrowserDialog1.ShowNewFolderButton = true;

            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                //第一字数组来接收=目录。获取文件（folder控件的选择的路径）
                string[] Files = Directory.GetFiles(folderBrowserDialog1.SelectedPath);
                foreach (string item in Files) //循环遍历
                {
                    //字符串截取，指定字符串出现‘.’+1的转换小写==“txt”的时候
                    if (item.Substring(item.LastIndexOf('.') + 1).ToLower() == "dxd")
                    {
                        //richbox控件.追加显示文本（数组集合）
                        Textbox3.AppendText(item + "\n");
                        DWDataReader dWDataReader = new DWDataReader();
                        if (dWDataReader.DWDataOpenFile(item)) { 
                            
                        int a = 0;

                            for (Int64 i = 0; i < dWDataReader.DwChannelCount; i++)
                            {
                                if (dWDataReader.DwChannelData[i].data != null)
                                {

                                    if (dWDataReader.DwChannelList[i].name == "P_H1")
                                    {
                                        a = a + 1;

                                    }

                                    ComboBox.Items.Add(dWDataReader.DwChannelList[i].name);
                                }
                                if (a >= 1)
                                {
                                    ComboBox.Text = "P_H1";
                                }
                                if (a < 1)
                                {
                                    ComboBox.Text = "请选择";
                                }
                            }
                        }
                    }

                }

            }
        }
    }
}


 
